def describe_2():
    print("With all due respect, I disagree.") 
    print("funs_1.py is  a very good file, but funs_2.py is the best ever")