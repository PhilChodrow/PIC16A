# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 14:20:23 2020

@author: micha
"""

#function definitions

def say_hello():
    
    print("Hello everybody! How are you doing today?")
    


#imperative commands

say_hello()
