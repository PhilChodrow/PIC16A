def describe_1():
    print("funs_1.py is the best .py file ever!")