def describe():
    print("The file top_level.py has been imported from our example module")
    print("We are executing the fuction describe.")